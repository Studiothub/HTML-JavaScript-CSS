function achiab(a, b)
{
	var t= a/b;
	return t;
}
try
{
	alert(achiab(16,1));
}catch(e){
	alert(e.message);
}
alert("tiep tuc")