var str = '{"name":"Phan Chau Tuan", "age":21}';
var obj = JSON.parse(str);
alert(obj.name)