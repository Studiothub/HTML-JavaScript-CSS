function hamdautien()
{
	alert("hello world")
}
hamdautien();