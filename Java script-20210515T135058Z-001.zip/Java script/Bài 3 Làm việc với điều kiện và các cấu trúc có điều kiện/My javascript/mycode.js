var a =5;
var b ='6';
var c;
/* c = a+b; */
c=a+5+b;
alert(c);