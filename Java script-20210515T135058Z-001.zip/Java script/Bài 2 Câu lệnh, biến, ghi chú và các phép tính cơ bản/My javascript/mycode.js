function hamdautien()
{
	/* alert("tuan"); */
}
hamdautien();